<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


//ini_set('display_errors', '1');
//error_reporting(E_ALL);

abstract class model_core_abstract {

    protected $registry;

    function __construct($registry) {
        
        $this->registry = $registry;
        $this->wakeupActive();
    }

//    ç.  $this->$registry->router->module.'/model

    function wakeupActive() {

        ActiveRecord\Config::initialize(function($cfg) {
                    $model = LUCID_MODULES . $this->registry->router->module . '/model';

                    $cfg->set_model_directory($model);

                    $cfg->set_connections(array(
                        'development' =>  $this->registry->connections));
                });
    }

}

?>
