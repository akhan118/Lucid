all files define in this folder must also have the name of the file and the name of the class the same.

example

app_core_controller_abstract file ... will have a class in it name app_core_controller_abstract .
