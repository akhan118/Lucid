<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


class error_controller extends app_core_controller_abstract
{
    
    
    function index()
    {
        echo 'error controller coming from';
        
    }
    
      function view()
    {
        
        echo 'this is id';
        
    }
    
    
}

?>
