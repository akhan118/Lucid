<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


class thankyou_controller extends app_core_controller_abstract
{
    
    function index()
    {
        
        echo 'thank you';
    }
    
    
}
?>
