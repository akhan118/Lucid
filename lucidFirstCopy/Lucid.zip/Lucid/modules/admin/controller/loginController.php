<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



class login_controller extends app_core_controller_abstract
{
    
    
    function index()
    {
        
        echo ' admin controller';
        
    }
    
    function view($id)
    {
        echo $id;
        echo ' this is the view function in login controller';
        
    }
    
    
    
    
}



?>
