<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



class index_controller extends app_core_controller_abstract
{
    
    
    function index() {
		
		
	//$this->registry->router->$controller_file;
        
        
        $this->registry->layout->homepage='
Lucid PHP Framework, intends to provide a basic PHP MVC framework 
for any application without future constrains.
The framework provide a simple , flexiable and lucid
approach to software developoments with PHP.            

'; 
        
       $this->registry->layout->view('index');
        
    }
    
    
    
    function view()
    {
        
        
        echo 'view';
    }
    
}


?>
