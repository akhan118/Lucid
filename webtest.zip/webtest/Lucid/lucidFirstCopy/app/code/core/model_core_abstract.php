<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

abstract class model_core_abstract
{
    
    protected $registry;
            
    function __construct($registry) {
       
        $this->registry=$registry;
    }
    
    
    
    
    
    
}
?>
