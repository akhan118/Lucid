<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


class index_controller extends app_core_controller_abstract
{
    
    
    function index(){
    echo ' this is index admin';
    }
    
    function view()
    {
        
        
        echo ' this is view coming from admin controller';
    }
}



?>
